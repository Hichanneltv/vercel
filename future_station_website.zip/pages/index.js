import { useEffect, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

export default function Home() {
  const { scrollY } = useScroll();
  const rotate = useTransform(scrollY, [0, 500], [0, 360]);

  return (
    <main className="bg-black text-white font-sans rtl">
      {/* Content omitted for brevity */}
    </main>
  );
}
